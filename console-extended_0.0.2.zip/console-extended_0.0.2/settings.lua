data:extend(
    {
        {
            type = "bool-setting",
            name = "cli-ext-adminOnly",
            setting_type = "startup",
            default_value = false,
        }
    }
)